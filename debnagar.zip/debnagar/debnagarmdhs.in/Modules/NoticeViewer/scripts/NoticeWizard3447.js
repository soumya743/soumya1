﻿$(document).ready(function () {
    $("#ajax-loader-container").hide();

    

    $.getJSON(url, function (data) {

        $("#ajax-loader-container").show();
        var items = [];


        $.each(data, function (key, val) {


            var iconhtml = data[key].IconColumnSize != null ?
                '<div class="' + (data[key].IconColumnSize != null ? 'col-md-' + data[key].IconColumnSize : '') + ' text-center">' + data[key].Icon + '</div>' : '';

            var closebuttonhtml = '<div class="text-right p-0"><i class="fa fa-times-circle close-btn" aria-hidden="true"  title="Close"></i></div>';

            var noticehtml = 
                '<div class="notice  ' + (data[key].CSSClass != null ? data[key].CSSClass : '') + ' shadow" >' +
                closebuttonhtml +
                
                '<div class="row" >' +

                iconhtml +

                '<div class="' + (data[key].IconColumnSize != null ? 'col-md-' + (12 - parseInt(data[key].IconColumnSize)) : 'col-md-12') + '">' +
                (data[key].ShowTitle == true ? '<h6 class="m-0">' + data[key].Title + '</h6>' : '') +
                data[key].Body +
                '</div>' +

                //'<div class="col-md-1 text-right pt-0"><i class="fa fa-times-circle close-btn" aria-hidden="true"  title="Close"></i></div>' +
                '</div> </div>';


            items.push(noticehtml);
            //console.log(noticehtml);
        });


        var allnotices = items.join("");

        $("#notice-widge-container").html(allnotices);




    })
        .always(function () {
            $("#ajax-loader-container").hide();
        });

    ;


    $("#notice-widge-container").on("click", ".close-btn", function (event) {
        $(this).parent().parent(".notice").hide('slow');
    });



});